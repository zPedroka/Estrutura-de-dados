public class Pilha {
    private int capacidade;
    private int topo;
    private int[] dados;
    private int maximo;

    public Pilha(int capacidade) {
        this.dados = new int[capacidade];
        this.topo = -1;
        this.maximo = capacidade;

    }

    public void inserir(int item) {
        if (this.topo == (this.maximo - 1)) {
            System.out.printf("\n A pilha està cheia \n");
        } else {
            this.dados[++this.topo] = item;
        }
    }

    public void remover() {
        if (this.topo == -1) {
            return;

        }
    }

    public void imprimir(){
        for (int i = topo; i >= 0; i--){
            System.out.println(dados[i]);
    }}
    public boolean vazia() {
        if (topo == -1) {
            return true;
        }
        else{
            return false;

        }
    }
    public boolean cheio(){
        if (topo == capacidade){
            return true;
        }
        else {
            return false;
        }
    }
}