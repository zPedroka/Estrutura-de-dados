public class Fila {
    private int [] dados;
    private int inicio;
    private int fim;
    private int capacidade;

public Fila (int incio, int fim, int[] dados, int capacidade){
    this.inicio = inicio;
    this.fim = fim;
    this.dados = dados;
    this.capacidade = capacidade;

    }

    public boolean cheia(){
        if ((inicio == 0 && fim == capacidade ) || (fim==(inicio-1))){
            return true;
        }else {
            return false;
        }


    }
    public boolean vazia(){
    if (inicio == fim && (dados[inicio] == -1)){
        return true;
    }
    else {
        return false;
    }
    }


}
